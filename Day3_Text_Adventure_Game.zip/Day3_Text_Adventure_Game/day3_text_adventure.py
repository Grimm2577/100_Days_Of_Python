# This is my submission for day 3 of the python 100 days boot camp.

print('''\n
*******************************************************************************
          |                   |                  |                     |
 _________|________________.=""_;=.______________|_____________________|_______
|                   |  ,-"_,=""     `"=.|                  |
|___________________|__"=._o`"-._        `"=.______________|___________________
          |                `"=._o`"=._      _`"=._                     |
 _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
|                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
|___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
          |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
 _________|___________| ;`-.o`"=._; ." ` '`."\ ` . "-._ /_______________|_______
|                   | |o ;    `"-.o`"=._``  '` " ,__.--o;   |
|___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
/______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
/______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
/______/______/______/______/______/______/______/______/______/______/_____ /
*******************************************************************************
\n''')
print("Welcome to Treasure Island.")
print("Your mission is to find the treasure.")

# printing the first question and checking if left was chosen else its death
question_1 = input("You dock near a cliff of a mysterious island\n"
                   "and once the crew set out to explore you came upon a fork in the road\n"
                   "which way do you go? left or right?\n")
if question_1 != "left":
    print("Fall into a hole, GAME OVER?")
else:
    question_2 = input("After you chose the left path you came upon a lake \n"
                       "filled with electric eels, you see a ferryman in the distance\n"
                       "swim or wait?\n")
    # printing the second question and using the lower() function to check user inputs
    if question_2.lower() != "wait":
        print("Attacked by trout. Game Over")
    else:
        # printing the third question and using the lower() function to check user inputs
        question_3 = input("After waiting for the ferryman and traversing the lake\n"
                           "on the ferrymans' raft you see a tomb with 3 doors painted\n"
                           "in different hues\n"
                           "which door shall you take? red, blue, or yellow?\n")
        if question_3.lower() == "blue":
            print("Eaten by beasts, Game over")
        elif question_3.lower() == "red":
            print("Burned by fire, Game Over")
        elif question_3.lower() == "yellow":
            print("You Win!")
        else:
            print("You had a stroke, Game Over!")
