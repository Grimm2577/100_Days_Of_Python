# Day7 done and dusted this days project actually took me a couple of hours when it came to making sure the guess string doesnt get overwritten
# each time, anyways this was a fun project with good difficulty scaling unfortunately the code is almost 1:1 to the video cause of how the 
# the project was setup in the pycharm, but i did do the work myself so i guess thats what counts

#importing random to choose a random word
import random

#importing the words from the hang man words library
import hangman_words

#importing the art from the hang man art library
import hangman_art

# setting the player lives to 6
lives = 6

# printing the game logo then choosing a random word
print(hangman_art.logo)
chosen_word = random.choice(hangman_words.word_list)

# creating a place holder string to display how many characters long the word is
placeholder = ""

# looping throught the word length and adding underscores for each char
word_length = len(chosen_word)
for position in range(word_length):
    placeholder += "_"
print("Word to guess: " + placeholder)

# setting up a game state boolean to keep the game running instead of running once and closing
game_over = False

# creating an array for all the correct letters weve guessed
correct_letters = []

while not game_over:

    # printing the amount of lives a user has at the start of the game and then receiving a guess via input function
    print(f"****************************<{lives}>/6 LIVES LEFT****************************")
    guess = input("Guess a letter: ").lower()

   
    # creating a temp string to store the guesses letters and undersccores
    display = ""

    # looping through the characters of the chosen word and then appending the correct letters and underscores to the strings and list 
    for letter in chosen_word:
        if letter == guess:
            display += letter
            correct_letters.append(guess)
        elif letter in correct_letters:
            display += letter
            print(f"You've already guessed : {guess}")
        else:
            display += "_"
    # printiing how much of the word is left to guess after each attempt
    print("Word to guess: " + display)


    # if the guessed letter is not in the word we subtract a life
    if guess not in chosen_word:
        lives -= 1
        print(f"{guess} Is not a letter in the word!, Life Lost!")

    # if the lifes run out the game closes out and were prompted with a loss screen
    if lives == 0:
        game_over = True

        print(f"It Was {chosen_word}\n***********************YOU LOSE**********************")

    # printing a win screen if there are no more underscores    
    if "_" not in display:
        game_over = True
        print("****************************YOU WIN****************************")

    # printing the hang man art after each mistake / entry
    print(hangman_art.stages[lives])
